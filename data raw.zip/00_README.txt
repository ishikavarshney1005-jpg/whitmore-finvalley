                    WHITMORE STRUCTURED CREDIT OPPORTUNITIES
                    FUND II, L.P. - CASE STUDY DATASET
                    STRUCTURED DEBT + DERIVATIVES SLEEVE

                  Companion to the Caldwell & Crane Partners
                  LAIM Case Study (Sections 5-6, Exhibits 2 & 3)

--------------------------------------------------------------------------------
CONTENTS
--------------------------------------------------------------------------------

01_Fund_Overview_Memo.txt              Internal GP memo describing the
                                       sleeve at a high level

02_Greystone_Facility_Agreement_Excerpt  Excerpts from the fund's revolver
    .txt                               credit facility agreement

03_Loan_Book_ServicerAlpha_2025Q4.csv  Loan tape from Servicer Alpha

04_ServicerBeta_LoanTape_Dec25.txt     Loan tape from Servicer Beta
                                       (different format)

05_Revolver_Utilization_Report.csv     Revolver drawn/undrawn balances
                                       over the year

06_CDS_Confirmation_OrionStudios.txt   Credit Default Swap confirmation
                                       + post-event ops note

07_IRS_Confirmation_Greystone.txt        Interest Rate Swap confirmation

08_FX_Forward_Confirmations.txt        Email export of FX forward
                                       confirmations and settlement

09_Options_Positions_PrimeBroker.tsv   Prime broker options position
                                       report

10_Broker_MTM_Statement_Dec2025.json   Consolidated MTM statement from
                                       prime broker

11_PM_Trading_Notes.txt                Portfolio manager's informal
                                       trading notebook

12_Cash_Ledger_Q4_2025.csv             Raw cash movement ledger for the
                                       final quarter

13_LP_Capital_Calls_and_Distributions  Compiled schedule of capital
    .txt                               calls and distributions to LPs

14_Leased_Assets_Registry.csv          Registry of leased assets across
                                       office, IT, and content library

15_Counterparty_Exposure_Snapshot.csv  Counterparty exposure snapshot
                                       (multiple source systems)

16_Corporate_Actions_Notices.txt       Compiled corporate action notices
                                       from various sources

--------------------------------------------------------------------------------
NOTES
--------------------------------------------------------------------------------

- These files are provided as they arrived from various source systems.
  No cleaning, reconciliation, or normalization has been performed.

- Files may contain typos, inconsistencies, notes, and annotations
  from various operations personnel. These are part of the raw data
  and should not be assumed to be authoritative just because they are
  written down.

- Certain files reference other files by name. Assume you have access
  to all files in this directory.

- Formal contract terms (ISDA confirmations, lease agreements, credit
  agreements) govern. Emails, notes, and sticky-notes are context, not
  authority.

- Where formal contracts are silent or ambiguous, you must form and
  document an assumption before computing any metric.

--------------------------------------------------------------------------------
